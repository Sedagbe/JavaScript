package source;

class MaClass implements NomInterface {

	public void afficher() {
		System.out.println("Implementation de la methode afficher");
	}
}
