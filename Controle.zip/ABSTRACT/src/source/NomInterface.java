package source;

public interface NomInterface {
//constante
	int NOMBRE_MAX = 10;
	//methode abstraite(par defaut,implicitement public et abstract)
	void afficher();
	
	
	//methode par defaut(Java 8+)
	default void saluer() {
		System.out.println("Bonjour depuis l'interface !");
	}
	//methode statique(java 8+)
	static void info() {
		System.out.println("Methode statique d'une interface");
	}
}
