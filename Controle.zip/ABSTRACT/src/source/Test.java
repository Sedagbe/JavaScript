package source;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MaClass obj = new MaClass();
		obj.afficher();
		obj.saluer();
		NomInterface.info();

	}

}
