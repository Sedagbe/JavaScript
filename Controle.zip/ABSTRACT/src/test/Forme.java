package test;

abstract class Forme {
protected String couleur;
public Forme(String couleur) {
	this.couleur=couleur;
}

//Methode concrete 
public void affichercouleur(){
	System.out.println("couleur:"+couleur);
}

//Méthode abstraite (à redéfinir)
abstract double calculerSurface();
}






