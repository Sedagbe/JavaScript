package test;

//Classe concrète qui hérite de Forme

class Rectangle extends Forme {
private double longueur, largeur;
public Rectangle(String couleur, double longueur, double largeur) {
super(couleur);
this.longueur = longueur;
this.largeur = largeur; }

//Redéfinition de la méthode abstraite
double calculerSurface() {
return longueur * largeur; }}