package test;

public class Test {
public static void main(String[] args) {
	
	
Rectangle r = new Rectangle("Bleu", 5, 3);
r.affichercouleur();
System.out.println("Surface : " + r.calculerSurface()); 
}
}
