package Test;

public class Arbitre {
	 private String nom;
	    private String prenom;
	    private String code;
	public Arbitre(String nom,String prenom,String code) {
		// TODO Auto-generated constructor stub
		this.nom=nom;
		this.prenom=prenom;
		this.code=code;
	}
	public String getNom() 
	{ return nom; }
    public String getPrenom() 
    {return prenom;}
    public String getCode() 
    { return code; }
    public String getNomComplet() {
        return prenom + " " + nom;
    }
    public String toString() {
        return getNomComplet() + " (Code: " + code + ")";
    }
    }

