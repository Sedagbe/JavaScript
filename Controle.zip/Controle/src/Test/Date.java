package Test;

public class Date {
	private int jour;
    private int mois;
    private int annee;
	public Date(int jour,int mois ,int annee) {
		// TODO Auto-generated constructor stub
		this.jour=jour;
		this.mois=mois;
		this.annee=annee;
		
	}
	public int getJour() 
	{ return jour; }
    public int getMois() 
    { return mois; }
    public int getAnnee() 
    { return annee; }
    public String toString() {
        return "Jour:"+jour +"Mois:"+mois+"Annee:"+annee;
}}
