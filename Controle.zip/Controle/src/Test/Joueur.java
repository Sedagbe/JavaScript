package Test;

public class Joueur {

	private String nom;
    private String prenom;
    private int age;
	public Joueur(String nom,String prenom,int age) {
		// TODO Auto-generated constructor stub
		this.nom=nom;
		this.prenom=prenom;
		this.age=age;
	}
	public String getNom() 
	{ return nom; }
    public String getPrenom()
    { return prenom; }
    public int getAge() 
    { return age; }
    public String getNomComplet() {
        return prenom + " " + nom;
    }
    public String toString() {
        return getNomComplet() + " (" + age + " ans)";
    }
}