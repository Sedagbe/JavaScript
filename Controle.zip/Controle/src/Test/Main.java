package Test;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
	Joueur j1 = new Joueur("Nadal", "Rafael", 36);
      Joueur j2 = new Joueur("Djokovic", "Novak", 35);
     Joueur j3 = new Joueur("Federer", "Roger", 40);
      Joueur j4 = new Joueur("Medvedev", "Danill", 26);
        
      Arbitre a1 = new Arbitre("Dupont", "Pierre", "A101");
     Arbitre a2 = new Arbitre("Martin", "Claire", "A102");
        
     Date dateMatch1 = new Date(12, 6, 2025);
      Date dateMatch2 = new Date(13, 6, 2025);
        
     Match m1 = new Match(j1, j2, a1, "6-4, 6-3", dateMatch1);
     Match m2 = new Match(j3, j4, a2, "7-6, 6-7, 6-2", dateMatch2);
       
    ArrayList<Match> matchesTournoi = new ArrayList<>();
       matchesTournoi.add(m1);
       matchesTournoi.add(m2);
     Date dateTournoi = new Date(12, 6, 2025);
     Tournoi tournoi = new Tournoi("Open de Test", dateTournoi, matchesTournoi);
      System.out.println(tournoi.toString());
      String gagnant1 = m1.gagnerMatch();
     System.out.println("Le gagnant du match " + j1.getNomComplet() + " VS " + j2.getNomComplet() + " est \n: " + gagnant1);
      String gagnant2 = m2.gagnerMatch();
     System.out.println("Le gagnant du match " + j3.getNomComplet() + " VS " + j4.getNomComplet() + " est : " + gagnant2);
        
       
	}

}
