package Test;

import java.util.Random;


public class Match {
private Joueur joueur1;
private Joueur joueur2;
private Arbitre arbitre;
private String resultat;
private Date date;
	public Match(Joueur joueur1, Joueur joueur2, Arbitre arbitre, String resultat, Date date) {
		// TODO Auto-generated constructor stub
		this.joueur1 = joueur1;
        this.joueur2 = joueur2;
        this.arbitre = arbitre;
        this.resultat = resultat;
        this.date = date;
	}
	 public Joueur getJoueur1() 
	 { return joueur1; }
	    public Joueur getJoueur2()
	    { return joueur2; }
	    public Arbitre getArbitre()
	    { return arbitre; }
	    public String getResultat() 
	    { return resultat; }
	    public Date getDate()
	    { return date; }
	    
	public String gagnerMatch() {
        Random random = new Random();
        int nombreAleatoire = random.nextInt(2); 
        
        if (nombreAleatoire == 0) {
            return joueur1.getNomComplet();
        } else {
            return joueur2.getNomComplet();
        }
    }
	public String toString() {
        return "Match: " + joueur1.getNomComplet() + " VS " + joueur2.getNomComplet() +  " Arbitre: " + arbitre.getNomComplet() ;
}}
 