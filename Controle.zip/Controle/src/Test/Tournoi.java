package Test;

import java.util.ArrayList;

public class Tournoi {
	private String nom;
    private Date date;
    private ArrayList<Match> matches;
	public Tournoi(String nom,Date date,ArrayList<Match> matches) {
		// TODO Auto-generated constructor stub
		this.nom = nom;
        this.date = date;
        this.matches = matches;
	}
	 public String getNom() 
	 { return nom; }
	    public Date getDate() 
	    { return date; }
	    public ArrayList<Match> getMatches() 
	    { return matches; }
	    
	 public void ajouterMatch(Match match) {
	        matches.add(match);}
	    
	 public String toString() {
	        return "Tournoi: " + nom + ", Date: " + date + " \n Matches: " + matches;
	    }   
	 
}	
	        
	     
	    

