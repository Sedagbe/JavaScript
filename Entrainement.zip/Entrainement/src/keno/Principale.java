package keno;

public class Principale {

	public static void main(String[] args) {
		String[] tab = {"Alex", "Ali", "Emily"};
		 Salle s = new Salle("Biologie 101", tab);
		 s.afficherSalle();
	}

}
