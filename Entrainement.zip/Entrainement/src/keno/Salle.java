package keno;

public class Salle {
private String classe;
private String[] Etudiants;
	public Salle(String classe,String []Etudiants) {
		this.classe=classe;
		this.Etudiants=Etudiants;

	}
public void afficherSalle() {
	System.out.println("Nom du classe: " + classe);
    System.out.print("Étudiants: ");
    for (String e : Etudiants) {
        System.out.print(e+" ");
    }
    System.out.println();
}
}

