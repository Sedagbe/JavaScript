package keno;

public class oou {

	public oou() {
		// TODO Auto-generated constructor stub
	}

}
