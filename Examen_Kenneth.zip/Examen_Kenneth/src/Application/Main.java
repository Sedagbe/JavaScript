package Application;
import Shopping.*;
import java.util.Date;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//creation des utilisateurs
Vendeur vendeur1 = new Vendeur("Alice","alice@email.com","pass123");
Acheteur acheteur1 = new Acheteur("Bob","bob@email.com","pass456");
Acheteur acheteur2 = new Acheteur("Charlie","charlie@email.com","pass789");
Administrateur admin = new Administrateur("Admin", "admin@email.com", "admin123");

//inscription et connexion
vendeur1.sinscrire();
acheteur1.sinscrire();
acheteur2.sinscrire();
admin.sinscrire();

vendeur1.seConnecter();
acheteur1.seConnecter();
acheteur2.seConnecter();
admin.seConnecter();

//creation et publication d'un objet 

Objet objet1 = new Objet("Montre de luxe","Montre en or",new Date());
vendeur1.ajouterObjet(objet1);
vendeur1.publierEnchere(objet1, 1000);

//validation par l'administrateur 
admin.validerObjet(objet1);

//les acheteurs placent des enchères
acheteur1.placerEnchere(objet1, 1200);
acheteur2.placerEnchere(objet1, 1500);
acheteur1.placerEnchere(objet1, 1600);

//consultation de l'historique

acheteur1.consulterHistorique();
acheteur2.consulterHistorique();

//resultat de l'enchère 

Enchere gagnante = objet1.getEnchereGagnante();
System.out.println("L'enchere gagante pour"+objet1.getNom()+"est de"+gagnante.getMontant()+"par"+gagnante.getUtilisateur().getNom());
	}

}
