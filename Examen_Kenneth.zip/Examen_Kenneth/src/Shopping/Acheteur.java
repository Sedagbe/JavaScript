package Shopping;

import java.util.ArrayList;
import java.util.List;

public class Acheteur extends Utilisateur implements UtilisateurInteractif{

private List<Enchere> enchereHistorique;

    
public Acheteur(String nom, String email, String motDepasse) {
super(nom, email, motDepasse);
        this.enchereHistorique = new ArrayList<>();
    }

    
 public void placerEnchere(Objet objet, double montant) {
        
        Enchere enchere = new Enchere(this, objet, montant);
        
        objet.ajouterEnchere(enchere);
        
        enchereHistorique.add(enchere);
        
        System.out.println(this.nom + " a placé une enchère de " + montant + " sur " + objet.getNom());
    }

public void consulterHistorique() {
        System.out.println("Historique des enchères de " + this.nom + " :");
        
        for (Enchere e : enchereHistorique) {
            System.out.println("- " + e.getObjet().getNom() + " : " + e.getMontant());
        }
    }


	@Override
public void seDeconnecter() {
		// TODO Auto-generated method stub
		System.out.println(this.nom + " est maintenant déconnecté.");
	}
}