package Shopping;

public class Administrateur extends Utilisateur  {

public Administrateur(String nom, String email, String motDepasse) {
        
super(nom, email, motDepasse);
    }

    
public void validerObjet(Objet objet) {
        
System.out.println("objet valide par l'administrateur: " + objet.getNom());
    }











}