package Shopping;

import java.util.Date;

public class Enchere {

private Acheteur utilisateur;
 private Objet objet;
    private double montant;
 private Date date;

   
public Enchere(Acheteur utilisateur, Objet objet, double montant) {
        this.utilisateur = utilisateur;
        this.objet = objet;
        this.montant = montant;
        this.date = new Date(); 
    }

public double getMontant() {
return montant;
    }

public Acheteur getUtilisateur() {
return utilisateur;
    }

 public Objet getObjet() {
 return objet;
    }

public Date getDate() {
return date;
    }

public String toString() {return "Offre de " + montant + "€ par " + utilisateur.getNom() + " le " + date;
    }
}