package Shopping;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public class Objet {

private String nom;
private String description;
private double prixDepart;
private Date dateFinEnchere;
private List<Enchere> listeEncheres;

    
public Objet(String nom, String description, Date dateFinEnchere) {
        this.nom = nom;
        this.setDescription(description);
        this.setDateFinEnchere(dateFinEnchere);
        this.listeEncheres = new ArrayList<>();
    }
public String getNom() {
    return nom;
  }

 public void setPrixDepart(double prixDepart) {
 this.prixDepart = prixDepart;
    }

   
 public void ajouterEnchere(Enchere enchere) {
        
 this.listeEncheres.add(enchere);
    }

   
 public Enchere getEnchereGagnante() {
        if (listeEncheres.isEmpty()) {
            return null;  }
Enchere meilleureEnchere = listeEncheres.get(0);
       
        for (Enchere e : listeEncheres) {
            if (e.getMontant() > meilleureEnchere.getMontant()) {
                meilleureEnchere = e;
            }
        }
 return meilleureEnchere;
    }
 public String toString() {return nom + " (Prix départ: " + prixDepart + ")";
    }

 public Date getDateFinEnchere() {
	return dateFinEnchere;
 }

 public void setDateFinEnchere(Date dateFinEnchere) {
	this.dateFinEnchere = dateFinEnchere;
 }

public String getDescription() {
	return description;
 }

public void setDescription(String description) {
	this.description = description;
 }
}