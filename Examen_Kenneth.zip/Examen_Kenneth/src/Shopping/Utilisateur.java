package Shopping;

public abstract class Utilisateur {
protected String nom;
protected String email;
protected String motDepasse;


 public Utilisateur(String nom, String email, String motDepasse) {
        this.nom = nom;
        this.email = email;
        this.motDepasse = motDepasse;
    }


public void sinscrire() {
 System.out.println(this.nom + " est inscrit avec l'email " + this.email);
    }
    
public void seConnecter() {
System.out.println(this.nom + " est maintenant connecté.");
    }
 public String getNom() { return nom; }
 public String getEmail() { return email; }
}