package Shopping;

public interface UtilisateurAvance extends UtilisateurInteractif{
	
void gererUtilisateur();    
void validerObjet(Objet objet);
}
