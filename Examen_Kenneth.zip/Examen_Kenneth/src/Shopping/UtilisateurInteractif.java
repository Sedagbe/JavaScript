package Shopping;

public interface UtilisateurInteractif {
void seConnecter();
void seDeconnecter();
}
