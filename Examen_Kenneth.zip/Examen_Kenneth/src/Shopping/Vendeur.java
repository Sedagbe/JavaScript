package Shopping;

import java.util.ArrayList;
import java.util.List;

public class Vendeur extends Utilisateur implements UtilisateurInteractif{
private List<Objet> objetsEnVente;

   
public Vendeur(String nom, String email, String motDepasse) {
        
super(nom, email, motDepasse);
 this.objetsEnVente = new ArrayList<>();
    }

    
public void ajouterObjet(Objet objet) {
objetsEnVente.add(objet);
 System.out.println("Objet " + objet.getNom() + " ajouté au stock de " + this.nom);
    }

   
public void supprimerObjet(Objet objet) {
   if (objetsEnVente.contains(objet)) {
    objetsEnVente.remove(objet);
   System.out.println("Objet retiré de la vente.");}
   else {
            System.out.println("Erreur : Cet objet n'appartient pas à ce vendeur.");
        }
    }

public void publierEnchere(Objet objet, double prixDepart) {
       
 if (!objetsEnVente.contains(objet)) {
           
ajouterObjet(objet);
        }
objet.setPrixDepart(prixDepart);

System.out.println("enchere publiée pour " + objet.getNom() + " avec prix depart " + prixDepart);
    }


@Override
public void seDeconnecter() {
	// TODO Auto-generated method stub
	System.out.println(this.nom + " est maintenant déconnecté.");	
}
}