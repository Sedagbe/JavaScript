package voiture;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Voiture v1 = new Voiture();
		Voiture v2 = new Voiture();
		System.out.println("v1\n" + v1);
		System.out.println("v2\n" + v2);
		v1.setCouleur("Bleu");
		v1.setMarque("Peugeot");
		v1.setVitesse(150);
		v2.setCouleur("Rouge");
		v2.setMarque("Renault");
		v2.setVitesse(160);
		System.out.println("v1\n" + v1);
		System.out.println("v2\n" + v2);
		Voiture v3 = new Voiture("Tesla","Gris",210);
		Voiture v4 = new Voiture("Citroen","Noir",155);
		System.out.println("v3\n" + v3);
		System.out.println("v4\n" + v4);
		System.out.println(Voiture.nbvoiture);
		Personne p1 = new Personne("Bob");
		System.out.println("la classe de v1 est : " + v1.getClass());
		System.out.println("la classe de p1 est : " + p1.getClass());
		System.out.println(v1 instanceof Voiture);
		System.out.println(p1 instanceof Personne);
	}

}
