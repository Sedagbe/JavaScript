package voiture;

public class Voiture {
	private String marque;
	private String couleur;
	private int vitesse;
	static int nbvoiture = 0;
	
	public Voiture(String marque, String couleur, int vitesse) {
		this.marque = marque;
		this.couleur = couleur;
		this.vitesse = vitesse;
		Voiture.nbvoiture++ ;
	}
	public Voiture() {
		this.marque = "Inconnue";
		this.couleur = "Aucune";
		this.vitesse = 0;
		Voiture.nbvoiture++;
	
	}
	public String getMarque() {
		return marque;
	}
	public void setMarque(String marque) {
		this.marque = marque;
	}
	public String getCouleur() {
		return couleur;
	}
	public void setCouleur(String couleur) {
		this.couleur = couleur;
	}
	public int getVitesse() {
		return vitesse;
	}
	public void setVitesse(int vitesse) {
		this.vitesse = vitesse;
	}
	public String toString() {
		return "Marque : " + marque + "\nCouleur : " + couleur + "\nVitesse : " + vitesse +"km/h\n";
	}
	public int getnbVoiture() {
		return nbvoiture;
	}
}
