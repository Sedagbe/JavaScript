package Evaluation;
import java.util.Random;

public class Bateau {
    private String nom;
    private int capaciteMax;
    private int cargaison;
    private double chiffreAffaire;
    private boolean enMer;

    public Bateau(String nom, int capaciteMax) {
        this.nom = nom;
        this.capaciteMax = capaciteMax;
        this.cargaison = 0;
        this.chiffreAffaire = 0;
        this.enMer = false;
    }

    public void sortirEnMer() {
        if (enMer) {
            System.out.println("Le bateau est déjà en mer");
        } else {
            enMer = true;
            System.out.println("Le bateau sort en mer");
        }
    }

    public void rentrerAuPort() {
        if (!enMer) {
            System.out.println("Le bateau est déjà au port");
        } else {
            enMer = false;
            System.out.println("Le bateau rentre au port");
        }
    }

    public void pecher() {
        if (!enMer) {
            System.out.println("Impossible de pêcher : le bateau est au port");
            return;
        }
        Random random = new Random();
        int kgPeches = random.nextInt(500);
        if (cargaison + kgPeches > capaciteMax) {
            System.out.println("Danger : surcharge !");
            cargaison = 0;
        } else {
            cargaison = cargaison + kgPeches;
            System.out.println("Cargaison : " + cargaison + " / Capacité : " + capaciteMax + " kg");
        }
    }

    public void vendre(Mareyeur acheteur) {
        if (enMer) {
            System.out.println("Vous devez rentrer au port avant de vendre");
            return;
        }
        if (cargaison == 0) {
            System.out.println("Rien à vendre");
            return;
        }

        double montant = cargaison * acheteur.getCoursDuMarche();
        chiffreAffaire += montant;

        System.out.println("Vente effectuée : " + cargaison + " kg à " + acheteur.getCoursDuMarche() + " €/kg");
        System.out.println("Gain : " + montant + " €");
        System.out.println("Chiffre d'affaire total : " + chiffreAffaire + " €");

        cargaison = 0;
    }

    public void print() {
        System.out.println("\n==== Tableau de bord ====");
        System.out.println("Nom : " + nom);
        System.out.println("État : " + (enMer ? "En mer" : "Au port"));
        System.out.println("Cargaison : " + cargaison + "/" + capaciteMax + " kg");
        System.out.println("Chiffre d'affaire : " + chiffreAffaire + " €");
        System.out.println("=========================\n");
    }
}
