package Evaluation;
import java.util.Random;

public class Mareyeur {
private String nom;
private static int coursDuMarche;
public Mareyeur(String nom) {
	this.nom = nom;
}
public static int getCoursDuMarche() {
	return coursDuMarche;
}
public static void setCoursDuMarche(int nouveauCours) {
	coursDuMarche = nouveauCours;
}
public String getNom() {
	return nom;
}
}
