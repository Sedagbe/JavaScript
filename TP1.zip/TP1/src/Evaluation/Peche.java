package Evaluation;
import java.util.Random;

public class Peche {

    public static void main(String[] args) {
        Bateau maBarque = new Bateau("Joli Coeur", 6700);
        Mareyeur fernand = new Mareyeur("Chez Amir");
        Mareyeur.setCoursDuMarche(Utils.nouveauCours());
        System.out.println("Cours initial : " + Mareyeur.getCoursDuMarche() + " euros/kg");
        maBarque.print();
        boolean continuer = true;
        
        do {
            String action = Utils.lireChaine("(S)ortir, (R)entrer, (P)echer, (V)endre, (F)in");
            switch (action.charAt(0)) {
                case 'S':
                    maBarque.sortirEnMer();
                    break;
                case 'R':
                    maBarque.rentrerAuPort();
                    break;
                case 'P':
                    maBarque.pecher();
                    break;
                case 'V':
                    maBarque.vendre(fernand);
                    break;
                case 'F':
                    continuer = false;
                    System.out.println("Fin de la partie");
                    break;
                default:
                    System.out.println("Action inconnue");
                    break;
            }

            if (Utils.pileOuFace() && Utils.pileOuFace()) {
                Mareyeur.setCoursDuMarche(Utils.nouveauCours());
                System.out.println("*** Nouveau cours *** : " + Mareyeur.getCoursDuMarche() + " euros/kg");
            }
            maBarque.print();

        } while (continuer);
    }
}
