package Evaluation;
import java.util.*;
public class Utils {
private static Random random = new Random();
private static Scanner sc = new Scanner(System.in);

public static int kgPeches() {
	return random.nextInt(500);
}
public static int nouveauCours() {
	return random.nextInt(31);
}
public static boolean pileOuFace() {
	return random.nextBoolean();
}
public static String lireChaine(String message) {
	System.out.print(message +"");
	return sc.nextLine().toUpperCase();
}
}
