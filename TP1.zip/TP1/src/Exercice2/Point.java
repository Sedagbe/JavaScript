package Exercice2;

public class Point {
    private double x;
    private double y;
    
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }
    
    public double getX() {
    	return x; }
    public double getY() { 
    	return y; }
    
    public void setX(double x) {
    	this.x = x;	
    }
    public void setY(double y) {
    	this.y =y ;	
    }
    
    public void deplacer (double dx, double dy) {
    	x = dx+x;
    	y = dy+y;
    }
    
    public void pivoter(double alpha) {
         
        x = x * Math.cos(alpha) - y * Math.sin(alpha);
        y = x * Math.sin(alpha) + y * Math.cos(alpha);
        
    }
    
    public String toString() {
        return "(" + x + "," + y + ")";
    }
}   