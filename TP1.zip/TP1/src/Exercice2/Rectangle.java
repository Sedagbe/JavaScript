package Exercice2;
import java.util.Scanner;

public class Rectangle {
    private Point basGauche;
    private  Point basDroite;
    private Point hautGauche;
    private Point hautDroite;
//cosntructeur 1
    public Rectangle(Point basGauche, Point hautDroite) {
        this.basGauche = basGauche;
        this.hautDroite = hautDroite;
        this.basDroite = new Point(hautDroite.getX(), basGauche.getY());
        this.hautGauche = new Point(basGauche.getX(), hautDroite.getY());
    }
//constructeur 2
public Rectangle(double bx, double by,double kx ,double ky) {
	basDroite = new Point(bx,by);
	hautGauche = new Point(kx,ky);
	basGauche = new Point(basDroite.getX(),hautGauche.getX());
	hautDroite = new Point(hautGauche.getX(), basDroite.getY());
}
 public void deplacer(double dx,double dy) {
	 basGauche.deplacer(dx, dy);
	 hautDroite.deplacer(dx, dy);
	 basDroite.deplacer(dx, dy);
	 hautGauche.deplacer(dx, dy); 
 }
 
 public void pivoter(double alpha) {
basGauche.pivoter(alpha);
hautDroite.pivoter(alpha);
basDroite.pivoter(alpha);
hautGauche.pivoter(alpha);
 }
 
 public String toString() {
	    return "Rectangle{\n" +
	           "  basGauche=" + basGauche.toString() + ",\n" +
	           "  basDroite=" + basDroite.toString() + ",\n" +
	           "  hautGauche=" + hautGauche.toString() + ",\n" +
	           "  hautDroite=" + hautDroite.toString() + "\n" +
	           "}";
	}   
	public static void main(String[] args) {
		Point p1 = new Point(2,1);
		Point p2 = new Point(5,4);
		
		Rectangle r = new Rectangle(p1,p2);
		System.out.println("Rectangle initial");
		System.out.println(r.toString());
		r.pivoter(90);
		System.out.println("Rectangle apres relation");
		System.out.println(r.toString());
				
	}

}


