package Exercice3;

import java.util.*;

class Banque {
	 private String bic;
	 private List <CompteCourant> comptesCourants;
	 private List<CompteEpargne> comptesEpargnes;
	 private List<ComptePayant> comptesPayants;
	 
	 public Banque(String bic) {
	 this.bic = bic;
	 this.comptesCourants = new ArrayList<>();
	 this.comptesEpargnes = new ArrayList<>();
	 this.comptesPayants = new ArrayList<>();
	 }
	 
	 
	 public void ajouterCompteCourant(CompteCourant c) { comptesCourants.add(c); }
	 public void ajouterCompteEpargne(CompteEpargne c) { comptesEpargnes.add(c); }
	 public void ajouterComptePayant(ComptePayant c) { comptesPayants.add(c); }
	 public void afficherComptes() {
	 System.out.println("=== Banque " + bic + " ===");
	 for (CompteCourant c : comptesCourants) System.out.println(c.toString()) ;
	 for (CompteEpargne c : comptesEpargnes) System.out.println(c.toString()) ;
	 for (ComptePayant c : comptesPayants) System.out.println(c.toString()) ;
	 }
	 // Simulation du temps uniquement pour les comptes épargne
	 public void dansXAnnees(int nbAnnees) {
	 System.out.println("\n--- Simulation dans " + nbAnnees + " ans ---");
	 for (CompteEpargne c : comptesEpargnes) {
	 double futur = c.soldedansxannee(nbAnnees);
	 System.out.println("Le compte épargne " + c.getID() +
	 " aura un solde de " + futur + " après " + nbAnnees + " ans.");
	 }
	 }
	public static void main(String[] args) {
	 Banque banque = new Banque("BICBANK123");
	 // Création des comptes courants
	 CompteCourant cc1 = new CompteCourant("CC1", 1000, 2020, 500);
	 CompteCourant cc2 = new CompteCourant("CC2", 200, 2019, 300);
	 CompteCourant cc3 = new CompteCourant("CC3", 50, 2021, 100);
	 // Création des comptes épargne
	 CompteEpargne ce1 = new CompteEpargne("CE1", 1500, 2020, 2.5);
	 CompteEpargne ce2 = new CompteEpargne("CE2", 3000, 2018, 3.0);
	 CompteEpargne ce3 = new CompteEpargne("CE3", 10000, 2022, 1.8);
	 // Création des comptes payants
	 ComptePayant cp1 = new ComptePayant("CP1", 500, 2020, 2, 10);
	 ComptePayant cp2 = new ComptePayant("CP2", 800, 2021, 1.5, 8);
	 ComptePayant cp3 = new ComptePayant("CP3", 2000, 2019, 3, 15);
	 // Ajout des comptes à la banque
	 banque.ajouterCompteCourant(cc1);
	 banque.ajouterCompteCourant(cc2);
	 banque.ajouterCompteCourant(cc3);
	 banque.ajouterCompteEpargne(ce1);
	 banque.ajouterCompteEpargne(ce2);
	 banque.ajouterCompteEpargne(ce3);
	 banque.ajouterComptePayant(cp1);
	 banque.ajouterComptePayant(cp2);
	 banque.ajouterComptePayant(cp3);
	 // (1) Affichage initial
	 banque.afficherComptes();
	 // (2) Simulation dans 7 ans
	 banque.dansXAnnees(7);
	 // (3) Réaffichage après simulation
	 System.out.println("\n=== Comptes après 7 années ===");
	 banque.afficherComptes();
	 }}
