package Exercice3;

public class CompteCourant {
	private String id;
	private double solde;
	private int annee;
	private double decouvert;
	
	public CompteCourant(String id, double solde, int annee, double decouvert) {
		// TODO Auto-generated constructor stub
		this.id = id;
		this.solde = solde;
		this.annee = annee;
		this.decouvert = decouvert;
		
	}
	public String getID() {
		return id;
	}
	public double getSolde() {
		return solde;
	}
	public int getAnnee() {
		return annee;
	}
	public double getDecouvert() {
	    return decouvert;
	}   

public void setID(String id) {
	this.id = id;
}
public void setSolde(double solde) {
	this.solde = solde;
}
public void setAnnee(int annee) {
	this.annee = annee;
	}
public void setDecouvert(double decouvert) {
    this.decouvert = decouvert;
}   

public void deposer(double montant) {
	
 solde = solde + montant ;	
}
public void retirer(double montant) {
	if(solde - montant >=  decouvert) {
		solde = solde - montant;
	}
	else 
	System.out.println("solde insuffisante");	
}
 public String toString() {
	 return("compte courant" + id + "solde :"+solde + "annee:" +annee);
 }

}
