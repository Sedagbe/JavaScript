package Exercice3;



public class CompteEpargne {
	private String id;
	private double solde;
	private int annee;
     private   double interet;
	
	public CompteEpargne(String id, double solde, int annee, double interet) {
		
		this.id = id;
		this.solde = solde;
		this.annee = annee;
		this.interet = interet;
		
	}
	public String getID() {
		return id;
	}
	public double getSolde() {
		return solde;
	}
	public int getAnnee() {
		return annee;
	}
	public double getInteret() {
		return interet;
	}

public void setID(String id) {
	this.id = id;
}
public void setSolde(double solde) {
	this.solde = solde;
}
public void setAnnee(int annee) {
	this.annee = annee;
	}
public void setInteret(double interet) {
	this.interet = interet;}

public void deposer(double montant) {
	
 solde = solde + montant ;	
}
public void retirer(double montant) {
	if(solde - montant >=  0) {
		solde = solde - montant;
	}
	else 
	System.out.println("solde insuffisante");	
}
public double soldedansxannee(int nbannee) {
	return solde * Math.pow(1+interet/100,nbannee);
}
 public String toString() {
	 return("compte courant" + id + "solde :"+ solde + "annee" + annee + "taux d'interet :"+interet);
 }

}
