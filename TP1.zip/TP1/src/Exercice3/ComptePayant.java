package Exercice3;



public class ComptePayant {
	private String id;
	private double solde;
	private int annee;
    private double pourcentage;
    private double seuil;
    
	
	public ComptePayant(String id, double solde, int annee, double pourcentage,double seuil) {
		
		this.id = id;
		this.solde = solde;
		this.annee = annee;
		this.pourcentage = pourcentage;
		this.seuil=seuil;
		
		
	}
	public String getID() {
		return id;
	}
	public double getSolde() {
		return solde;
	}
	public int getAnnee() {
		return annee;
	}
	public double getPourcentage() {
		return pourcentage;
	}
	public double getSeuil() {
		return seuil;
	}
public void setID(String id) {
	this.id = id;
}
public void setSolde(double solde) {
	this.solde = solde;
}
public void setAnnee(int annee) {
	this.annee = annee;
	}
public void setPourcentage(double pourcentage) {
	this.pourcentage = pourcentage ;
	}
public void setSeuil(double Seuil) {
	this.seuil = seuil;
	}

public double calculerFrais(double montant) {
	return Math.min((montant*pourcentage/100),seuil);
}
public void deposer(double montant) {
	double frais = calculerFrais(montant);
	solde = solde+montant-frais;
}
public void retirer(double montant) {
	if(solde - montant >=  0) {
		double frais = calculerFrais(montant);
		solde = solde - montant-frais;
	}
	else 
	System.out.println("solde insuffisante");	
}

 public String toString() {
	 return("compte courant:" + id + "solde :"+ solde + "annee:" + annee + "Pourcentage :"+pourcentage+"Seuil:"+seuil);
 }

}
