package test;
import java.util.Scanner;
public class ComparaisonPhrase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Entrez la première phrase");
		String phrase = sc.nextLine();
		System.out.println("Entrez la deuxième phrase");
		String phrase1 = sc.nextLine();
		System.out.println(phrase.equals(phrase1));

		
	}

}
