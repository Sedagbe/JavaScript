package test;

public class Complexe {

private double re;
private double im;

//constructeur 
public Complexe(double re, double im) {

this.re = re;
this.im = im;
}
//Methode get et set

public double getRE() {
	return re;
}
public double getIM() {
	return im;
}
public void setRE(double re) {
	this.re = re;
}
public void setIM(double im) {
	this.im = im;
}

public Complexe addition(Complexe c){
Complexe resultat = new Complexe(c.re + this.re, c.im+this.im);	
return resultat;
}
public Complexe soustraction(Complexe c) {
Complexe resultat = new Complexe(this.re - c.re, this.im - im);
return resultat;
}
public String toString() {
	if (im >= 0)
		return re + "+" + im+ "i";
	else
		return re + "-" + im +"i";
}
}
