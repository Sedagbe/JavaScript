package test;

public class Complexe_principale {

	public static void main(String[] args) {
		Complexe c1 = new Complexe (3,4);
		Complexe c2 = new Complexe (1,-2);

		
//Affichage 
System.out.println("Premier nombre complexe"+ c1.toString());
System.out.println("Deuxième nombre complexe"+ c2.toString());

//Addition
Complexe somme = c1.addition(c2);
System.out.println("Somme ="+ somme.toString());
Complexe difference = c1.soustraction(c2);
System.out.println("difference ="+ difference.toString());

	}

}
