package test;
import java.util.Scanner;
public class Menu {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("______________MENU_______________");
		System.out.println("Faites un choix");
		
		int choix = 4;
		do {
			System.out.println("1-Calcul de factorielle d'un nombre");
			System.out.println("2-Afficher la table de multiplication d'un nombre");
			System.out.println("3-Vérifier si un nombre est premier");
			System.out.println("4-Quitter");
			choix=scanner.nextInt();
			
			
		switch(choix) {
		case 1:
			System.out.println("Cacul de factoriel");
			System.out.println("entrez un nombre");
			int nombre;
			nombre=  scanner.nextInt();
			int i = 0;
			int fact = 1;
			while(i < nombre) {
					fact = fact * (nombre - i);
				i++;
			}
			System.out.println("Le factoriel donne "+fact+"");	
			break;
			
			
		case 2:
			System.out.print("Entrez un nombre : ");
			int t = scanner.nextInt();
			System.out.println("Table de multiplication de " + t + " :");
			for (int j = 1; j <= 10; j++) {
			 System.out.println(t + " x " + j + " = " + (t * j)); }break;
			
		case 3:
			
			
		case 4:break;
			
		}
		}
		while(choix != 4);
		
		
		

}
}
