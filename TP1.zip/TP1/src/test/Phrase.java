package test;
import java.util.Scanner;
public class Phrase {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Entrez une phrase");
		String phrase = sc.nextLine();
		System.out.println("Longueur:"+ phrase.length());
		System.out.println("MAJUSCULE:"+ phrase.toUpperCase());
		System.out.println("Minuscules:"+ phrase.toLowerCase());

	}

}
