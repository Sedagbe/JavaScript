package test;
import java.util.Scanner;

public class SommeEntiers {

	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in).reset(); //permet la saisie au clavier 
	int[]nombre1 = new int[5]; // tableau 1 de 5 entiers
	int[]nombre2 = new int[5]; // tableau 2 de 5 entiers
	int[]somme = new int[5]; //somme
	
	
	//saisie des valeurs
	System.out.println("Veuillez saisir 5 entiers du tableau 1:");
	for (int i = 0; i < nombre1.length; i++) {
		System.out.print("Entier" +(i+1)+ ":");
		nombre1[i] = scanner.nextInt();}
	
	System.out.println("Veuillez saisir  5 entiers du tableau 2 :");
	for (int i = 0; i < nombre2.length; i++) {
		System.out.print("Entier" +(i+1)+ ":");
		nombre2[i] = scanner.nextInt();}
	
	//Affichage des valeurs 
	System.out.println("\n La somme des deux tableaux donne :");
	for(int i = 0; i <somme.length;i++) {
	System.out.println("somme["+i+"]="+(nombre1[i]+nombre2[i]));
	}
	scanner.close();
	}

	
}

