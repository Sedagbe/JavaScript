package test;
import java.util.Scanner;
public class SommedeMatrice {

	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in);
	int[][]matrice = new int[3][3];
	int[][]matrice1 =new int[4][4];
	
	//Déclaration d'une matrice 3x3
	//Saisie des valeurs
	
	System.out.println("Veuillez saisir les élements de la matrice 3x3 :");
	for(int i = 0; i < 3 ;i++) {
		for(int j=0; j< 3; j++) {
			System.out.print("Element["+i+"]["+j+"]:");
			matrice[i][j] =scanner.nextInt();
								}
							     }
	
	System.out.println("Veuillez saisir les élements de la matrice 4x4 :");
	for(int i = 0; i < 4 ;i++) {
		for(int j=0; j< 4; j++) {
			System.out.print("Element["+i+"]["+j+"]:");
			matrice1[i][j] =scanner.nextInt();
								}
							     }
//Affichage de la matrice
System.out.println("\n La matrice saisie est:");
for(int i= 0; i<4; i++) {
	for(int j = 0;j<3; j++) {
System.out.println(matrice1[i][j] + "\t");//tabulation pour l'alignement 
	}
System.out.println();}
scanner.close();
	}

}

