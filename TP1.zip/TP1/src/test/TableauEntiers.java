package test;
import java.util.Scanner;

public class TableauEntiers {

	public static void main(String[] args) {
	Scanner scanner = new Scanner(System.in).reset(); //permet la saisie au clavier 
	int[]nombres = new int[5]; // tableau de 5 entiers
	
	
	//saisie des valeurs
	System.out.println("Veuillez saisir 5 entiers :");
	for (int i = 0; i < nombres.length; i++) {
		System.out.print("Entier" +(i+1)+ ":");
		nombres[i] = scanner.nextInt();}
	
	//Affichage des valeurs 
	System.out.println("\n Les entiers saisis sont :");
	for(int i = 0; i <nombres.length;i++) {
	System.out.println("nombres["+i+"]="+nombres[i]);
	}
	scanner.close();
	}

	
}
