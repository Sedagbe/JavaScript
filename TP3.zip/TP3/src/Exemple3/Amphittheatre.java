package Exemple3;

public class Amphittheatre extends Salle{
	private int nbProjecteur;
	private int nbMicrophones;
	
	public Amphittheatre(int nbplaces,int numero,int superficie,int nbEtage,int nbProjecteur,int nbMicrophones) {
		super(nbplaces,numero,superficie,nbEtage);
		this.nbProjecteur=nbProjecteur;
		this.nbMicrophones=nbMicrophones;
	}
	public void afficher() {
		super.afficher();
		System.out.println("Nombre Projecteur :"+nbProjecteur+"\n Type de Microphones:"+nbMicrophones);
}}
