package Exemple3;

public class Salle {
protected int nbplaces;
protected int numero;
protected int superficie;
protected int nbEtage;
	public Salle(int nbplaces,int numero,int superficie,int nbEtage) {
		this.nbplaces=nbplaces;
		this.numero=numero;
		this.superficie=superficie;
		this.nbEtage=nbEtage;
	}
public void afficher() {
	System.out.print("Numero:"+numero+"\n Nombre de place:"+nbplaces+"\n Superficie:"+superficie+"\n Etage:"+nbEtage);
	
}
}
