package Exemple3;

public class SalleInformatique extends Salle {
private int nbEquipement;
private String typeSysteme;

	public SalleInformatique(int nbplaces,int numero,int superficie,int nbEtage,int nbEquipement,String typeSysteme) {
		super(nbplaces,numero,superficie,nbEtage);
		this.nbEquipement=nbEquipement;
		this.typeSysteme=typeSysteme;
		
	}
public void afficher() {
	super.afficher();
	System.out.println("Nombre Equipement:"+nbEquipement+"\n Type de sysyteme:"+typeSysteme);
}
}
