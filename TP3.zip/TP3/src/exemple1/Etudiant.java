package exemple1;

public class Etudiant extends Personne {
	
private String filiere;
private String groupe;
private int identifiant;
private double moyenne;
	public Etudiant(String nom,String prenom,int age,String filiere,String groupe,int identifiant,double moyenne) {
		super(nom,prenom,age);
		this.filiere=filiere;
		this.groupe=groupe;
		this.identifiant=identifiant;
		this.moyenne=moyenne;
	}
	
public String getFiliere() {
	return filiere;
}
public String getgroupe() {
	return groupe;
}
public int getIdentifiant() {
	return identifiant;
}
public double getMoyenne() {
	return moyenne;
}
public String toString() {
	
	return super.toString()+"\n Filiere:"+filiere+"\n Groupe:"+groupe+"\n Identifiant:"+identifiant+"\n Moyenne:"+moyenne+"\n -----";
}
}
