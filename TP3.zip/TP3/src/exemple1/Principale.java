package exemple1;
import java.util.ArrayList;
import java.util.List;


public class Principale {

	public static void main(String[] args) {
	List<Personne>Personnes= new ArrayList<>();
    Personnes.add(new Etudiant("Chris","MAHOUNGOU",23,"Medecine","A",13,18));
    Personnes.add(new Etudiant("Sergine","LANKOANDE",19,"Boucherie","Z",12,17));
	
	for(Personne etu : Personnes) {
		System.out.println(etu);
	}

	}}
