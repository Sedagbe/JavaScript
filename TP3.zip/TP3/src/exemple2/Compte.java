package exemple2;

public class Compte {
public float solde;


	public Compte() {this.solde=100;}
    public Compte(float s) {this.solde=s;}
    
    public void verser(float mt) {
    	solde+=mt;
    }
   public void retirer(float mt) {
	   if(mt<solde) solde-=mt;
   } 
   public String toString() {
	   return("le solde actuel="+solde);
   }
}
