package exemple2;

public class CompteEpargne extends Compte{
   double taux =0.05;
	public CompteEpargne(float s,double t) {
	super(s);
	this.taux = t;
	}
 public double SoldeDansXAnnees(int a) {
	 return this.solde*java.lang.Math.pow(1+taux, a);
 }

}
