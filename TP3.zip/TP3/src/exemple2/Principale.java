package exemple2;

public class Principale {

	public static void main(String[] args) {
		CompteEpargne cp = new CompteEpargne(200.0f,0.07f);
		System.out.println(cp.toString()); 

	}

}
